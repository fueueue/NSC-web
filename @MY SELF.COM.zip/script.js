const connectBtn = document.getElementById("connectBtn");
const status = document.getElementById("status");
const menuToggle = document.getElementById("menuToggle");
const sidebar = document.getElementById("sidebar");
const closeSidebar = document.getElementById("closeSidebar");
const freeBtn = document.getElementById("freeBtn");
const bypassBtn = document.getElementById("bypassBtn");

let isConnected = false;
let currentMode = "Free Internet";

// Connect/Disconnect Logic
connectBtn.addEventListener("click", () => {
  isConnected = !isConnected;
  status.textContent = `Status: ${isConnected ? "Connected" : "Disconnected"} (${currentMode})`;
  connectBtn.textContent = isConnected ? "Disconnect" : "Connect";
});

// Sidebar Toggle
menuToggle.addEventListener("click", () => {
  sidebar.style.left = "0";
});

closeSidebar.addEventListener("click", () => {
  sidebar.style.left = "-260px";
});

// Mode Toggle
freeBtn.addEventListener("click", () => {
  currentMode = "Free Internet";
  freeBtn.classList.add("active");
  bypassBtn.classList.remove("active");
});

bypassBtn.addEventListener("click", () => {
  currentMode = "Geo Bypass";
  bypassBtn.classList.add("active");
  freeBtn.classList.remove("active");
});